namespace CalculadoraImc.Core;

public class Operacoes
{
    public double CalcularImc(double pesoKg, double alturaMetros)
    {
        if (pesoKg <= 0)
            throw new ArgumentOutOfRangeException(nameof(pesoKg), "O peso deve ser maior que zero.");

        if (alturaMetros <= 0)
            throw new ArgumentOutOfRangeException(nameof(alturaMetros), "A altura deve ser maior que zero.");

        double imc = pesoKg / (alturaMetros * alturaMetros);
        return Math.Round(imc, 2);
    }

    public string ClassificarImcAbeso(double imc)
    {
        if (imc <= 0 || double.IsNaN(imc) || double.IsInfinity(imc))
            throw new ArgumentOutOfRangeException(nameof(imc), "O IMC deve ser um valor válido maior que zero.");

        if (imc < 18.5)
            return "Baixo peso";

        if (imc <= 24.9)
            return "Peso normal";

        if (imc <= 29.9)
            return "Sobrepeso";

        if (imc <= 34.9)
            return "Obesidade Grau I";

        if (imc <= 39.9)
            return "Obesidade Grau II";

        return "Obesidade Grau III";
    }
}
