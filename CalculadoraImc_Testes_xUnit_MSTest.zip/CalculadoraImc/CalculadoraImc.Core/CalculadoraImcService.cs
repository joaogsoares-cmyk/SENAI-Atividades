namespace CalculadoraImc.Core;

public record ResultadoImc(double Imc, string Classificacao);

public class CalculadoraImcService
{
    private readonly Operacoes _operacoes;

    public CalculadoraImcService(Operacoes operacoes)
    {
        _operacoes = operacoes ?? throw new ArgumentNullException(nameof(operacoes));
    }

    public ResultadoImc CalcularEClassificar(double pesoKg, double alturaMetros)
    {
        double imc = _operacoes.CalcularImc(pesoKg, alturaMetros);
        string classificacao = _operacoes.ClassificarImcAbeso(imc);
        return new ResultadoImc(imc, classificacao);
    }
}
