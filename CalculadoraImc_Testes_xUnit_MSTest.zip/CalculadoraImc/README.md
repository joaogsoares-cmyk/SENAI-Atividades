# Calculadora de IMC (Padrão ABESO) - Testes Unitários (xUnit e MSTest)

Projeto desenvolvido para a atividade de testes unitários em sistemas *server-side* (.NET / C#), contemplando o cálculo do IMC e a classificação conforme os critérios da **ABESO**.

## Estrutura da Solução

- `CalculadoraImc.Core`: Biblioteca de domínio contendo a classe `Operacoes` e `CalculadoraImcService`.
- `CalculadoraImc.XUnitTests`: Projeto de testes unitários utilizando **xUnit**.
- `CalculadoraImc.MSTestTests`: Projeto de testes unitários utilizando **MSTest**.

## Como Executar os Testes

Na raiz do projeto, execute:

```bash
dotnet test --verbosity normal
```
