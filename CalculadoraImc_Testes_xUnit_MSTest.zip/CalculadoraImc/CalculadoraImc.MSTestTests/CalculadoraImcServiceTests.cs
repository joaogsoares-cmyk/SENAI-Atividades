using CalculadoraImc.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalculadoraImc.MSTestTests;

[TestClass]
public class CalculadoraImcServiceTests
{
    private CalculadoraImcService _service = null!;

    [TestInitialize]
    public void Setup()
    {
        _service = new CalculadoraImcService(new Operacoes());
    }

    [TestMethod]
    public void CalcularEClassificar_DeveRetornarImcEClassificacao()
    {
        ResultadoImc resultado = _service.CalcularEClassificar(68.0, 1.70);

        Assert.AreEqual(23.53, resultado.Imc);
        Assert.AreEqual("Peso normal", resultado.Classificacao);
    }
}
