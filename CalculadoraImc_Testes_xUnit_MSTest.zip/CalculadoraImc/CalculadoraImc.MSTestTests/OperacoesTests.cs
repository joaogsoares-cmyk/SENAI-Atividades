using CalculadoraImc.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalculadoraImc.MSTestTests;

[TestClass]
public class OperacoesTests
{
    private Operacoes _operacoes = null!;

    [TestInitialize]
    public void Setup()
    {
        _operacoes = new Operacoes();
    }

    [DataTestMethod]
    [DataRow(70.0, 1.75, 22.86)]
    [DataRow(50.0, 1.70, 17.30)]
    [DataRow(80.0, 1.75, 26.12)]
    [DataRow(95.0, 1.75, 31.02)]
    [DataRow(110.0, 1.75, 35.92)]
    [DataRow(130.0, 1.75, 42.45)]
    public void CalcularImc_DeveRetornarValorEsperado(double peso, double altura, double imcEsperado)
    {
        double resultado = _operacoes.CalcularImc(peso, altura);

        Assert.AreEqual(imcEsperado, resultado);
    }

    [DataTestMethod]
    [DataRow(0.0, 1.75)]
    [DataRow(-70.0, 1.75)]
    [DataRow(70.0, 0.0)]
    [DataRow(70.0, -1.75)]
    public void CalcularImc_DeveLancarExcecao_QuandoEntradaInvalida(double peso, double altura)
    {
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => _operacoes.CalcularImc(peso, altura));
    }

    [DataTestMethod]
    [DataRow(18.49, "Baixo peso")]
    [DataRow(18.50, "Peso normal")]
    [DataRow(24.90, "Peso normal")]
    [DataRow(25.00, "Sobrepeso")]
    [DataRow(29.90, "Sobrepeso")]
    [DataRow(30.00, "Obesidade Grau I")]
    [DataRow(34.90, "Obesidade Grau I")]
    [DataRow(35.00, "Obesidade Grau II")]
    [DataRow(39.90, "Obesidade Grau II")]
    [DataRow(40.00, "Obesidade Grau III")]
    [DataRow(45.50, "Obesidade Grau III")]
    public void ClassificarImcAbeso_DeveRetornarClassificacaoCorreta(double imc, string classificacaoEsperada)
    {
        string resultado = _operacoes.ClassificarImcAbeso(imc);

        Assert.AreEqual(classificacaoEsperada, resultado);
    }

    [DataTestMethod]
    [DataRow(0.0)]
    [DataRow(-10.0)]
    [DataRow(double.NaN)]
    [DataRow(double.PositiveInfinity)]
    public void ClassificarImcAbeso_DeveLancarExcecao_QuandoImcInvalido(double imc)
    {
        Assert.ThrowsException<ArgumentOutOfRangeException>(() => _operacoes.ClassificarImcAbeso(imc));
    }
}
