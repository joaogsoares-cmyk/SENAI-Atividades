using CalculadoraImc.Core;
using Xunit;

namespace CalculadoraImc.XUnitTests;

public class CalculadoraImcServiceTests
{
    private readonly CalculadoraImcService _service = new(new Operacoes());

    [Theory]
    [InlineData(68.0, 1.70, 23.53, "Peso normal")]
    [InlineData(85.0, 1.75, 27.76, "Sobrepeso")]
    [InlineData(100.0, 1.75, 32.65, "Obesidade Grau I")]
    public void CalcularEClassificar_DeveRetornarImcEClassificacao(
        double peso,
        double altura,
        double imcEsperado,
        string classificacaoEsperada)
    {
        ResultadoImc resultado = _service.CalcularEClassificar(peso, altura);

        Assert.Equal(imcEsperado, resultado.Imc);
        Assert.Equal(classificacaoEsperada, resultado.Classificacao);
    }
}
